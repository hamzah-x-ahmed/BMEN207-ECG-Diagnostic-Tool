# -*- coding: utf-8 -*-
"""
Created on Wed Oct 31 15:19:06 2018

"""

# Initializing modules
import numpy as np
from scipy import signal as sig
import matplotlib.pyplot as plt
#%% Suppressing Future Warnings in the console
# Future Warnings are output, despite all attempts to remedy. In order to not 
#   burden the user, warnings are suppressed in the console
import sys
import warnings

if not sys.warnoptions:
    warnings.simplefilter("ignore")
#%% Initializing the Program
# A while loop is initialized. So long as the while loop is in effect, the user
#   can load and reload data to get as many diagnoses as needed.     
state=1
while state==1:
#   User is asked what they would like to do.    
    decision=int(input("What would you like to do? Please input the number corresponding with your choice:\n"+
                       "1) Load and Diagnose \n2) Exit the program\n"))
#   User has chosen to load and diagnose    
    if decision==1:       
#%% Importing Data
#       User is asked to input the name of a text file in the same folder as the
#           .py file        
        fname=input("Enter the name of a local text file, with extension:\n")
#       The following represents defunct code that would allow for users to select
#           any file they choose, in any directory, similar to MATLAB's "uigetfile"
#           command. However, due to the GUI components locking up, this code will 
#           remain in comments.        
#        import tkinter as tk
#        from tkinter import filedialog
#        root = tk.Tk()
#        root.withdraw()
#        fname = filedialog.askopenfilename()
#       The file the user specified is open in a "read only" format        
        f=open(fname,"r")
#       The text file is read line by line, and transcribed into text_data        
        text_data=f.readlines()
#       The user specified file is closed        
        f.close()
#%% Unpacking text_data
#       Retrieves Patient number and prints to console
        Patient_info=text_data[0].split()
        print("\nPatient ID: "+Patient_info[1])
#       Retrieves time step
        line_2=text_data[1].split()
        step=float(line_2[2])
#       Retrieves voltage information by loading all data after the 2nd row
        voltage=np.loadtxt(fname,skiprows=2)
#       Creates a time list to match the voltages
        time=[]
        for x in range (0,len(voltage)):
            time.append(x*step)
#%% Filtering
#       Removes the linear offset from the voltage data
        voltage_detrended=sig.detrend(voltage)
#       Determines the Nyquist frequency for the voltage data        
        f_nyquist=(1/step)/2
#       An arbitrarily chosen cutoff frequency determined through trial and error
        f_cutoff_low= .00001
        f_cutoff_high= 40
        Wn= [f_cutoff_low/f_nyquist , f_cutoff_high/f_nyquist]
#       A bandpass filter is performed using the butter function
        b,a=sig.butter(3,Wn,btype="band")
        voltage_filtered=sig.filtfilt(b,a,voltage_detrended,axis=0)
#%% Detecting P and R
#       A threshold voltage is defined. Anything above this threshold is considered
#           an R wave, anything below is considered a P wave.        
        volt_threshold_R=max(voltage_filtered)*.75
#       Indices for peaks are found using the voltage data        
        peaks=(sig.find_peaks(voltage_filtered,prominence=0.15))[0]
#       Corresponding voltage for each peak is found using the indices
        peak_voltage=voltage_filtered[peaks]
#       Necessary lists are initialized as blank        
        peak_time=[]
        R_voltage=[] 
        R_time=[]
        P_voltage=[]
        P_time=[]
        for x in range (0,len(peaks)):
#           Corresponding times are found for each peak            
            peak_time.append(time[peaks[x]])
#           If the voltage at each peak is greater than the threshold, time and voltage
#               data are stored in an additional series of lists specific to R waves            
            if peak_voltage[x]>=volt_threshold_R:
                R_voltage.append(peak_voltage[x])
                R_time.append(peak_time[x])
#           If not, time and voltage data are stored in P wave-specific lists                
            else:
                P_voltage.append(peak_voltage[x])
                P_time.append(peak_time[x])
#%% Detecting Q and S (using inverted data)
#       The process above is repeated for Q and S waves. The one significant difference
#           is that the voltage originally used is inverted, hence the negative sign.                
        volt_threshold_S=max(-voltage_filtered)*.8
        peaks_inverted=(sig.find_peaks(-voltage_filtered,prominence=0.15))[0]
        peak_voltage_inverted=-voltage_filtered[peaks_inverted]
        peak_time_inverted=[]
        S_voltage=[] 
        S_time=[]
        Q_voltage=[]
        Q_time=[]
        for x in range (0,len(peaks_inverted)):
            peak_time_inverted.append(time[peaks_inverted[x]])
            if peak_voltage_inverted[x]>=volt_threshold_S:
#               In order to make sure the voltage stored in the S list accurately
#                   reflects the original voltage data, the peak voltage is uninverted
#                   using an additional negative sign.                
                S_voltage.append(-peak_voltage_inverted[x])
                S_time.append(peak_time_inverted[x])
            else:
                Q_voltage.append(-peak_voltage_inverted[x])
                Q_time.append(peak_time_inverted[x])        
#%% Diagnostic Values
        RR_interval=np.diff(R_time)
        PP_interval=np.diff(P_time)
        PR_interval=[]
        PR_diff=[]
        for i in range (0,len(R_time)):
            for j in range (0,len(P_time)):
                PR_diff.append(abs((P_time[j])-(R_time[i])))
            PR_interval.append(min(PR_diff))
        QS_interval=[]
        QS_diff=[]
        for i in range(0,len(S_time)):
            for j in range (0,len(Q_time)):
                QS_diff.append(abs((Q_time[j])-(S_time[i])))
            QS_interval.append(min(QS_diff))
#%% Analyzing for BPM
#        BPM is calculated with respect to the average length of a beat, using the
#           RR interval
        BPM=int(round(60/np.mean(RR_interval)))
#       Calculated BPM is then printed to console
        print(f"Patient heart rate: {BPM} bpm")
#%% Diagnoses
        if BPM<60:
#           A standard deviation of .3 in the RR interval would indicate a
#               missed QRS complex, a characteristic of AV Block, 2nd Degree
            if np.std(RR_interval)>= .3:
                diagnosis= 'AV block, second degree'
#           A PR-interval longer than 0.2 seconds is characteristic of AV Block, 1st Degree.
#               Because AV1 happens in patients with high, low, and normal heart
#               rates, I have included this diagnostic criterion in all 3 cases.
            elif min(PR_interval)>0.2:
                diagnosis= 'AV block, first degree'
#           If none of the other diagnostic characteristics match, the patient is diagnosed
#               simply based on their low heart rate.
            else:
                diagnosis='Sinus bradycardia'    
        elif BPM>60 and BPM<100:
#           If the range of RR and PP intervals exceeds 0.16, the patient is diagnosed with Sinus Arrhythmia.
#               In order to differentiate from Atrial fibrillation, the number of P waves must also be less than 25.            
            if ((max(RR_interval)-min(RR_interval))>0.16 and \
                (max(PP_interval)-min(PP_interval))>0.16) and \
                len(P_voltage)<25:
                diagnosis= 'Sinus arrhythmia'
#           If the number of P waves exceeds 40, the patient is experiencing atrial
#               fibrillation                
            elif len(P_voltage)>=40:
                diagnosis= "Atrial fibrillation"
#           If every QRS complex duration exceeds .07 seconds, then the patient is 
#               diagnosed with BBB                
#           elif min(QS_interval)>0.07:
#                diagnosis="Bundle branch block"                
            elif min(PR_interval)>0.2:
                diagnosis= "AV block, first degree"
#           If all else fails, the patient is diagnosed as normal                
            else:
                diagnosis="NORMAL"
        else:
            if min(PR_interval)>0.2:
                diagnosis= "AV block, first degree"
#           The patient hasn't met criterion for AV Block 1, so they are diagnosed
#               with tachycardia, the only other condition characterized by a high
#               heart rate.                
            else:
                diagnosis="Sinus tachycardia"
        print("Diagnosis: "+diagnosis)
#%% Termination Clause of program
# If the user selects the option to exit the program, the while loop is broken 
#   and the program exits
    else:
#       Reminds the user to have a nice day, breaks the while loop condition, and 
#           ends the program.        
        print("Have a nice day!")
        state=0
#%% Plotting for Quality Inspection (will be commented out when turned in)
#plt.cla
#plt.plot(time,voltage_filtered,'b-', label="filtered")
#plt.plot(time,voltage_detrended,'r--', label="unfiltered")
#plt.plot(R_time,R_voltage,'bo',label="R")
#plt.plot(P_time,P_voltage,'go',label="P")
#plt.plot(Q_time,Q_voltage,'gv',label="Q")
#plt.plot(S_time,S_voltage,'bv',label="S")
#plt.legend()

            
    
