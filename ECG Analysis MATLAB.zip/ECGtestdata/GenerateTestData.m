clear
close all

%% read in ECG data file
disp('Select ECG file to analyze') %diplay instructions
[FileName,PathName] = uigetfile('*.txt','Select the ECG file to analyze'); %display file select gui
f = fullfile(PathName,FileName); %assemble filename with fullpath
fprintf('file loaded: %s \r',FileName);
delimiterIn = ' ';
headerlinesIn = 1;
A = importdata(f,delimiterIn,headerlinesIn); %import data from specified file using stated delimiter and number of header lines
ecgrawtrace=A.data'; %put data into variable
str=strsplit(A.textdata{:},' '); %split header string up and place into cell
dt=str2num(str{6}) %extract time step interval from header string
Lead=str2num(str{3}); %extract time step interval from header string
time=(0:length(ecgrawtrace)-1)*dt;

figure(1);subplot(3,1,1);plot(time, ecgrawtrace);xlabel('time (s)');ylabel('voltage (mV)')

%% resample data with new sampling rate, range 0.5 - 2 kHz (0.002 to 0.0005)
new_dt=0.0006
new_time=0:new_dt:time(end);

resampled_ecgrawtrace = interp1(time,ecgrawtrace,new_time, 'spline');

time= new_time;
ecgrawtrace=resampled_ecgrawtrace;
dt=new_dt
subplot(3,1,2);plot(time, ecgrawtrace);xlabel('time (s)');ylabel('voltage (mV)')
%% add noise and offset

noise_amplitude=max(ecgrawtrace)*0.08;
noise=noise_amplitude*(rand(size(ecgrawtrace)).*2-1); %create noise array with a mean of 0
m=2*(rand*2-1)
b=10*(rand*2-1)
offset=m*time+b;
data_plus_noise=noise+ecgrawtrace+offset;

testecgtrace=data_plus_noise;

subplot(3,1,3);plot(time, testecgtrace);xlabel('time (s)');ylabel('voltage (mV)')

%% build header for file and write files

new_protoheader = str;
str_dt=num2str(dt);
str_dt=str_dt(2:end);
patient=dec2hex(round(rand(1)*1e7),7)
header1=sprintf('Patient %s', patient)
%header2= sprintf('%s %s %s %s %s %s %s %s %u',str{1},str{2},str{3},str{4},str{5}, str_dt, str{7}, str{8}, length(testecgtrace))
header2= sprintf('%s %s %s %s %s %s %s %s %u',str{4},str{5}, str_dt, str{1},str{2},str{3}, str{7}, str{8}, length(testecgtrace))

%%write files
%noise free file
new_filename_root=FileName(1:length(FileName)-4)
new_filename=sprintf('%s%s',new_filename_root,'.txt')
%f2 = fullfile(PathName,new_filename);
f2 = fullfile('./',new_filename);
fid2=fopen(f2,'w');
data=num2str(ecgrawtrace, '%0.7e\n');
fprintf(fid2, '%s\n%s\n%s\n ',header1, header2, data);
fclose(fid2);

%noise file
new_filename_root=FileName(1:length(FileName)-4)
new_filename=sprintf('%s%s',new_filename_root,'_noise.txt')
%f3 = fullfile(PathName,new_filename);
f3 = fullfile('./',new_filename);
fid3=fopen(f3,'w');
data=num2str(testecgtrace, '%0.7e\n');
fprintf(fid2, '%s\n%s\n%s\n ',header1, header2, data);
fclose(fid3)