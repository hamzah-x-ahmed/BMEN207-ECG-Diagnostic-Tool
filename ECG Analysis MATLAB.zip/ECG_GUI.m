% Any pre-existing remnants of data are cleared from the workspace to
% ensure no "data contamination"
clear;
close all;
% Constructor function for GUI is initialized
ECGgui

function ECGgui(~)
    % The GUI is originally defined
    gui=figure('Visible','off','Name','ECG Diagnosis','Menubar','none','units','normalized',...
        'position',[0 0 .7 .7],'NextPlot','replacechildren');
    % The button the user interacts with is initialized so that, upon
    % clicking, the callback function begins running
    Load_button=uicontrol(gui,'string','Load and Analyze','units','normalized',...
        'position',[.7,.1,.25,.1],'callback',@load);
    % The GUI is moved to the center and made visible so that the user can
    % see and interact with it.
    movegui(gui,'center');
    gui.Visible='on';
% Callback function that begins to run when user clicks on the Load button
function load(~,~)
%% Loading Data from .txt File
% User selects the desired file. Automatically checks for errors by forcing
% user to select only from .txt files, eliminates possibility of typo
% errors.
[file,path]=uigetfile('*.txt','Choose the desired file with ECG Data');
% The entire name is pieced together using the path information and the
% name of the file in question
full_file_name=fullfile(path,file);
% If a user has not selected a file, prints out a receipt of cancellation
% and ends the program.
if file==0
    fprintf('User cancelled input\n');
    return
% If a user did select a file, prints out the name and path of the file    
else
    fprintf('File chosen: %s\n',full_file_name)
    % The actual process for importing the text file contents as a string
    % array. The 9 column array is identified as all string, and excludes
    % new line breaks and carriage returns.
    formatSpec = '%s%s%s%s%s%s%s%s%s%[^\n\r]';
    % Opens the user specified file for reading only
    fileID = fopen(full_file_name,'r');
    % Reads through the contents of the specified file.
    text_contents = textscan(fileID, formatSpec, 'Delimiter', ' ', 'MultipleDelimsAsOne', true,...
        'TextType','string','ReturnOnError', false);
    fclose(fileID);
    % text_data represents a string array containing the contents of the text
    % file, extracted from text_contents
    text_data=[text_contents{1:end-1}];
    % data_count represents the number of numeric data points present,
    % calculated by taking the total number of rows of data, and then
    % subtracting 2 rows to account for the 2 rows of header information
    data_count=length(text_data)-2;
end
% cleans workspace by removing variables that aren't needed anymore in
% order to increase processing speed
clearvars path file full_file_name formatSpec fileID text_contents ans
%% Cracking Open text_data
% text_data contains a lot of different pieces of information that have to
% be grouped and organized into workable variables.
% 
% text_dim represents the number of rows and columns present in text_data,
% which can provide valuable indexing information.
text_dim=size(text_data);
text_rows=text_dim(1);    
%num_data represents all the numeric data in the text_data cell array
num_data=text_data(3:text_rows,1);
% step refers to the way time values increment
step=str2double(text_data{2,3});
% lead_num refers to the number of the lead electrode recording data.
% Although not necessary, based on rubric, necessary code to retrieve lead
% number is included here:
% lead_num=str2double(text_data{2,6});
% patient_info outputs a string of the patient number
patient_info=text_data{1,2};
%In order to plot, need x (time) and y (voltage) variables
for i=1:data_count
    % time starts at 0, increases in increments determined by step variable
    time(i,1)=step*(i-1);
    % In order to gather data from num_data into a numeric array, need to
    % traverse the cell one cell at a time and convert to a numeric
    % variable. This data is then stored in the voltage array.
    voltage(i,1)=str2double(num_data{i,1});
end
clearvars text_dim text_rows
%% add noise to the ECG Signal [for Quality Testing]
% noise_amplitude=max(voltage)*0.08; %signal: array of data from the text file
% noise=noise_amplitude*(rand(size(voltage)).*2-1);
% voltage=voltage+noise;
%% add offset to the ECG Signal [for Quality Testing]
% m=2*(rand*2-1); %random slope varying from -2 to 2 mV
% b=10*(rand*2-1); %random intercept varying from -10 to 10 mV
% offset=m*time+b; %time: time array the length of signal
% voltage=voltage+offset;
%% Noise Filtering
% Removes the linear offset from the voltage data
voltage=detrend(voltage);
% Determines the Nyquist frequency for the voltage data
f_nyquist=(1/step)/2;
% An arbitrarily chosen cutoff frequency determined through trial and error
f_cutoff_low= .000001;
f_cutoff_high= 40;
Wn= [f_cutoff_low/f_nyquist f_cutoff_high/f_nyquist];
% A bandpass filter is performed using the butter function
[b,a]=butter(3,Wn,'bandpass');
filtered_voltage=filter(b,a,voltage);
clearvars f_nyquist f_cutoff_low f_cutoff_high Wn b a
%% Plotting the Data
%ECG data is plotted with time on the x-axis and voltage on the y-axis
% cla is used to ensure that residual plots from previous selections are
% not carried over.
cla
% hold is turned on to allow both plots to be superimposed over each other,
% so that user can see difference between unfiltered and filtered wave
% forms.
hold on
noisy=plot(time,voltage,'b-');
% In order to accomodate later output areas, the graph window for the noisy
% plot is resized on the parent GUI.
noisy.Parent.Units='normalized'; 
noisy.Parent.Position=[.1 .1 .5 .75];
filtered=plot(time,filtered_voltage,'r-');
% Similar resizing is done for the filtered plot.
filtered.Parent.Units='normalized'; 
filtered.Parent.Position=[.1 .1 .5 .75];
%hold is turned off to ensure that, if the user chooses to plot new data in
%the same session, that new plots aren't superimposed over old plots.
hold off
% Graph is completed by providing user reference information regarding axes
% and line colors.
legend([noisy filtered],'noisy','filtered');
title('ECG Signal vs. Time');
ylabel('ECG Signal (mV)');
xlabel('Time (s)');
%% PQRS Wave Detection
% volt_threshold represents the threshold above which a peak is defined.
% This threshold is determined by taking the maximum of the voltage data
% set, and then multiplying by .8; when applied, anything that is above
% that threshold will include any peaks that are within 20% of that maximum
% value.
volt_threshold_R=max(filtered_voltage)*.8;
% Peak voltages are stored in peak, times at which these peaks occur stored
% in peak_location
[peak,peak_location]=findpeaks(filtered_voltage,time,'MinPeakDistance',.02, 'MinPeakHeight', .1);
% Included to identify where peaks are on graph, uncomment if needed
% findpeaks(filtered_voltage,time,'MinPeakDistance',.02, 'MinPeakHeight', .1)
j=1;
k=1;
% Determines value and location of P and R waves
for i=1:length(peak)
    if peak(i)>=volt_threshold_R
        R_voltage(j)=peak(i);
        R_time(j)=peak_location(i);
        j=j+1;
    else
        P_voltage(k)=peak(i);
        P_time(k)=peak_location(i);
        k=k+1;
    end
end
% In order to determine the values and time locations of Q and S waves, the
% above process must be repeated with a version of filtered_voltage that
% has been flipped across the x-axis.
% Peak voltages are stored in peak, times at which these peaks occur stored
% in peak_location
[peak,peak_location]=findpeaks(-filtered_voltage,time,'MinPeakDistance',.02, 'MinPeakHeight', .15);
% Included to identify where peaks are on graph, uncomment if needed.
% findpeaks(-filtered_voltage,time,'MinPeakDistance',.02, 'MinPeakHeight', .15)
j=1;
k=1;
% A new voltage threshold is established for determining S waves that takes
% all peaks within 20% of the maximum voltage value recorded in the
% inverted filtered sample.
volt_threshold_S=abs(min(filtered_voltage)*.8);
% Determines S and Q wave amplitudes and time locations
for i=1:length(peak)
    if peak(i)>=volt_threshold_S
        S_voltage(j)=peak(i);
        S_time(j)=peak_location(i);
        j=j+1;
    else
        Q_voltage(k)=peak(i);
        Q_time(k)=peak_location(i);
        k=k+1;
    end
end
%% Diagnostic Values
RR_interval=diff(R_time);
PP_interval=diff(P_time);
for i=1:numel(R_time)
    PR_interval(i)=min(abs(P_time-R_time(i)));
end
for i=1:numel(S_time)
    QS_interval(i)=min(abs(Q_time-S_time(i)));
end
%% Analyzing for BPM
% BPM is calculated with respect to the average length of a beat, using the
% RR interval
BPM=60/mean(RR_interval);
%% Diagnoses
% This if statement is used to create a variable that can operate as a
% switch for the subsequent switch-case, because nested if statements tend
% to take more processing time than switch case statements. A tiny initial
% sacrifice in time is made for this initial if statement in order to make
% subsequent processes more efficient.
if BPM<60
    BPM_indicator=1;
elseif BPM>60 && BPM<100
    BPM_indicator=2;
else
    BPM_indicator=3;
end
switch BPM_indicator
    case 1
        % A standard deviation of .3 in the RR interval would indicate a
        % missed QRS complex, a characteristic of AV Block, 2nd Degree
        if std(RR_interval)>= .3
            diagnosis= 'AV block, second degree';
        % A PR-interval longer than 0.2 seconds is characteristic of AV Block, 1st Degree.
        % Because AV1 happens in patients with high, low, and normal heart
        % rates, I have included this diagnostic criterion in all 3 cases.
        elseif PR_interval>0.2
            diagnosis= 'AV block, first degree';
        % This one is just for fun, really. If the data read indicates a
        % flat-line, there will either be no peaks, or the highest peak
        % would be less than .005. Although this wouldn't work if the
        % patient flat-lined in the middle... it's just for fun.
        elseif isempty(peak)==1 || max(peak)<.005
            diagnosis= 'DEAD';
        % If none of the other diagnostic characteristics match, the patient is diagnosed
        % simply based on their low heart rate.
        else
            diagnosis='Sinus bradycardia';
        end
    case 2
        if ((max(RR_interval)-min(RR_interval))>0.16 && (max(PP_interval)-min(PP_interval))>0.16)...
                && length(P_voltage)<25
            diagnosis= 'Sinus arrhythmia';
        elseif length(P_voltage)>=40
            diagnosis= 'Atrial fibrillation';
        elseif min(QS_interval)>0.07
            diagnosis='Bundle branch block';
        elseif PR_interval>0.2
            diagnosis= 'AV block, first degree';
        else
            diagnosis='NORMAL';
        end
    case 3
        if PR_interval>0.2
            diagnosis= 'AV block, first degree';
        else
            diagnosis='Sinus tachycardia';
        end
end
clearvars BPM_indicator
%% Final Results
% Patient information, BPM, and Diagnosis are reworked into strings with palatable appearances
Patient_Output=sprintf('Patient ID:%s',patient_info);
BPM_Output=sprintf('Patient Heart Rate:%2.4f bpm',BPM);
Diagnosis_Output=sprintf('Diagnosis: %s',diagnosis);
% Text boxes are created on the GUI to display the strings
Patient_Display=uicontrol('style','text','string',Patient_Output,'FontSize',12,...
    'units','normalized','position',[.6 .6 .5 .1]);
BPM_Display=uicontrol('style','text','string',BPM_Output,'FontSize',12,...
    'units','normalized','position',[.6 .5 .5 .1]);
Diagnosis_Display=uicontrol('style','text','string',Diagnosis_Output,'FontSize',12,...
    'units','normalized','position',[.6 .3 .5 .2]);
end
end
